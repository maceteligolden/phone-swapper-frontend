/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./src/lib/api.ts":
/*!************************!*\
  !*** ./src/lib/api.ts ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"sungloApi\": () => (/* binding */ sungloApi)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit/query/react */ \"@reduxjs/toolkit/query/react\");\n/* harmony import */ var _reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-redux-wrapper */ \"next-redux-wrapper\");\n/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst sungloApi = (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.createApi)({\n    baseQuery: (0,_reduxjs_toolkit_query_react__WEBPACK_IMPORTED_MODULE_0__.fetchBaseQuery)({\n        baseUrl: \"http://localhost:5000/api/v1/\",\n        prepareHeaders: (headers, { getState  })=>{\n            // By default, if we have a token in the state,\n            const token = getState().auth.token;\n            if (token) {\n                headers.set(\"authorization\", `Bearer ${token}`);\n            }\n            return headers;\n        }\n    }),\n    extractRehydrationInfo (action, { reducerPath  }) {\n        if (action.type === next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__.HYDRATE) {\n            return action.payload[reducerPath];\n        }\n    },\n    endpoints: (builder)=>({})\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvbGliL2FwaS50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUF5RTtBQUM1QjtBQVF0QyxNQUFNRyxZQUFZSCx1RUFBU0EsQ0FBQztJQUNqQ0ksV0FBV0gsNEVBQWNBLENBQUM7UUFDeEJJLFNBQVM7UUFDVEMsZ0JBQWdCLENBQUNDLFNBQVMsRUFBRUMsU0FBUSxFQUFFLEdBQUs7WUFDekMsK0NBQStDO1lBQy9DLE1BQU1DLFFBQWdCLFdBQTBCQyxJQUFJLENBQUNELEtBQUs7WUFDMUQsSUFBSUEsT0FBTztnQkFDVEYsUUFBUUksR0FBRyxDQUFDLGlCQUFpQixDQUFDLE9BQU8sRUFBRUYsTUFBTSxDQUFDO1lBQ2hELENBQUM7WUFFRCxPQUFPRjtRQUNUO0lBQ0Y7SUFDQUssd0JBQXVCQyxNQUFNLEVBQUUsRUFBRUMsWUFBVyxFQUFFLEVBQUU7UUFDOUMsSUFBSUQsT0FBT0UsSUFBSSxLQUFLYix1REFBT0EsRUFBRTtZQUMzQixPQUFPVyxPQUFPRyxPQUFPLENBQUNGLFlBQVk7UUFDcEMsQ0FBQztJQUNIO0lBQ0FHLFdBQVcsQ0FBQ0MsVUFBYSxFQUV6QjtBQUNGLEdBQUciLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9waG9uZS1zd2FwcGVyLWFwcC8uL3NyYy9saWIvYXBpLnRzPzJmYWIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlQXBpLCBmZXRjaEJhc2VRdWVyeSB9IGZyb20gXCJAcmVkdXhqcy90b29sa2l0L3F1ZXJ5L3JlYWN0XCI7XHJcbmltcG9ydCB7IEhZRFJBVEUgfSBmcm9tIFwibmV4dC1yZWR1eC13cmFwcGVyXCI7XHJcbmltcG9ydCB7IFJvb3RTdGF0ZSB9IGZyb20gXCIuL3N0b3JlXCI7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIEJhc2VNb2RlbCB7XHJcbiAgc3RhdHVzOiBudW1iZXI7XHJcbiAgbWVzc2FnZTogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3Qgc3VuZ2xvQXBpID0gY3JlYXRlQXBpKHtcclxuICBiYXNlUXVlcnk6IGZldGNoQmFzZVF1ZXJ5KHtcclxuICAgIGJhc2VVcmw6IFwiaHR0cDovL2xvY2FsaG9zdDo1MDAwL2FwaS92MS9cIixcclxuICAgIHByZXBhcmVIZWFkZXJzOiAoaGVhZGVycywgeyBnZXRTdGF0ZSB9KSA9PiB7XHJcbiAgICAgIC8vIEJ5IGRlZmF1bHQsIGlmIHdlIGhhdmUgYSB0b2tlbiBpbiB0aGUgc3RhdGUsXHJcbiAgICAgIGNvbnN0IHRva2VuOiBzdHJpbmcgPSAoZ2V0U3RhdGUoKSBhcyBSb290U3RhdGUpLmF1dGgudG9rZW5cclxuICAgICAgaWYgKHRva2VuKSB7XHJcbiAgICAgICAgaGVhZGVycy5zZXQoJ2F1dGhvcml6YXRpb24nLCBgQmVhcmVyICR7dG9rZW59YClcclxuICAgICAgfVxyXG5cclxuICAgICAgcmV0dXJuIGhlYWRlcnNcclxuICAgIH1cclxuICB9KSxcclxuICBleHRyYWN0UmVoeWRyYXRpb25JbmZvKGFjdGlvbiwgeyByZWR1Y2VyUGF0aCB9KSB7XHJcbiAgICBpZiAoYWN0aW9uLnR5cGUgPT09IEhZRFJBVEUpIHtcclxuICAgICAgcmV0dXJuIGFjdGlvbi5wYXlsb2FkW3JlZHVjZXJQYXRoXTtcclxuICAgIH1cclxuICB9LFxyXG4gIGVuZHBvaW50czogKGJ1aWxkZXIpID0+ICh7XHJcbiAgICBcclxuICB9KSxcclxufSk7XHJcbiJdLCJuYW1lcyI6WyJjcmVhdGVBcGkiLCJmZXRjaEJhc2VRdWVyeSIsIkhZRFJBVEUiLCJzdW5nbG9BcGkiLCJiYXNlUXVlcnkiLCJiYXNlVXJsIiwicHJlcGFyZUhlYWRlcnMiLCJoZWFkZXJzIiwiZ2V0U3RhdGUiLCJ0b2tlbiIsImF1dGgiLCJzZXQiLCJleHRyYWN0UmVoeWRyYXRpb25JbmZvIiwiYWN0aW9uIiwicmVkdWNlclBhdGgiLCJ0eXBlIiwicGF5bG9hZCIsImVuZHBvaW50cyIsImJ1aWxkZXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/lib/api.ts\n");

/***/ }),

/***/ "./src/lib/slice/authslice.ts":
/*!************************************!*\
  !*** ./src/lib/slice/authslice.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   \"logOut\": () => (/* binding */ logOut),\n/* harmony export */   \"selectCurrentToken\": () => (/* binding */ selectCurrentToken),\n/* harmony export */   \"selectCurrentUser\": () => (/* binding */ selectCurrentUser),\n/* harmony export */   \"setCredentials\": () => (/* binding */ setCredentials)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _utils_localstorage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../utils/localstorage */ \"./src/utils/localstorage.ts\");\n\n\nconst defaultUser = {\n    firstname: \"\",\n    id: \"\",\n    email: \"\",\n    verified: false\n};\nconst slice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({\n    name: \"auth\",\n    initialState: {\n        token: (0,_utils_localstorage__WEBPACK_IMPORTED_MODULE_1__.getFromLocalStorage)(\"token\") ? (0,_utils_localstorage__WEBPACK_IMPORTED_MODULE_1__.getFromLocalStorage)(\"token\") : \"\",\n        user: (0,_utils_localstorage__WEBPACK_IMPORTED_MODULE_1__.getFromLocalStorage)(\"user\") ? JSON.parse((0,_utils_localstorage__WEBPACK_IMPORTED_MODULE_1__.getFromLocalStorage)(\"user\") ?? JSON.stringify(defaultUser)) : defaultUser\n    },\n    reducers: {\n        setCredentials: (state, action)=>{\n            state.token = action.payload.token;\n            state.user = action.payload.user;\n        },\n        logOut: (state, action)=>{\n            state.token = \"\";\n            state.user = defaultUser;\n        }\n    }\n});\nconst { setCredentials , logOut  } = slice.actions;\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (slice.reducer);\nconst selectCurrentUser = (state)=>state.auth.user;\nconst selectCurrentToken = (state)=>{\n    return state.auth.token;\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvbGliL3NsaWNlL2F1dGhzbGljZS50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUE4RDtBQUNDO0FBVS9ELE1BQU1FLGNBQW9CO0lBQ3hCQyxXQUFXO0lBQ1hDLElBQUk7SUFDSkMsT0FBTztJQUNQQyxVQUFVLEtBQUs7QUFDakI7QUFPQSxNQUFNQyxRQUFRUCw2REFBV0EsQ0FBQztJQUN4QlEsTUFBTTtJQUNOQyxjQUFjO1FBQ1pDLE9BQU9ULHdFQUFtQkEsQ0FBQyxXQUFXQSx3RUFBbUJBLENBQUMsV0FBVyxFQUFFO1FBQ3ZFVSxNQUFNVix3RUFBbUJBLENBQUMsVUFBVVcsS0FBS0MsS0FBSyxDQUFDWix3RUFBbUJBLENBQUMsV0FBV1csS0FBS0UsU0FBUyxDQUFDWixnQkFBZ0JBLFdBQVc7SUFDMUg7SUFDQWEsVUFBVTtRQUNSQyxnQkFBZ0IsQ0FBQ0MsT0FBT0MsU0FBcUM7WUFDM0RELE1BQU1QLEtBQUssR0FBR1EsT0FBT0MsT0FBTyxDQUFDVCxLQUFLO1lBQ2xDTyxNQUFNTixJQUFJLEdBQUdPLE9BQU9DLE9BQU8sQ0FBQ1IsSUFBSTtRQUNsQztRQUNBUyxRQUFRLENBQUNILE9BQU9DLFNBQVc7WUFDekJELE1BQU1QLEtBQUssR0FBRztZQUNkTyxNQUFNTixJQUFJLEdBQUdUO1FBQ2Y7SUFDRjtBQUNGO0FBRU8sTUFBTSxFQUFFYyxlQUFjLEVBQUVJLE9BQU0sRUFBRSxHQUFHYixNQUFNYyxPQUFPLENBQUM7QUFDeEQsaUVBQWVkLE1BQU1lLE9BQU8sRUFBQztBQUN0QixNQUFNQyxvQkFBeUIsQ0FBQ04sUUFBcUJBLE1BQU1PLElBQUksQ0FBQ2IsSUFBSSxDQUFDO0FBQ3JFLE1BQU1jLHFCQUEwQixDQUFDUixRQUFxQjtJQUFFLE9BQU9BLE1BQU1PLElBQUksQ0FBQ2QsS0FBSztBQUFDLEVBQUUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9waG9uZS1zd2FwcGVyLWFwcC8uL3NyYy9saWIvc2xpY2UvYXV0aHNsaWNlLnRzPzAxOGEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlU2xpY2UsIFBheWxvYWRBY3Rpb24gfSBmcm9tIFwiQHJlZHV4anMvdG9vbGtpdFwiO1xyXG5pbXBvcnQgeyBnZXRGcm9tTG9jYWxTdG9yYWdlIH0gZnJvbSBcIi4uLy4uL3V0aWxzL2xvY2Fsc3RvcmFnZVwiO1xyXG5pbXBvcnQgeyBSb290U3RhdGUgfSBmcm9tIFwiLi4vc3RvcmVcIjtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgVXNlciB7XHJcbiAgZmlyc3RuYW1lOiBzdHJpbmcsXHJcbiAgaWQ6IHN0cmluZyxcclxuICBlbWFpbDogc3RyaW5nLFxyXG4gIHZlcmlmaWVkOiBib29sZWFuXHJcbn1cclxuXHJcbmNvbnN0IGRlZmF1bHRVc2VyOiBVc2VyID0ge1xyXG4gIGZpcnN0bmFtZTogJycsXHJcbiAgaWQ6ICcnLFxyXG4gIGVtYWlsOiAnJyxcclxuICB2ZXJpZmllZDogZmFsc2VcclxufVxyXG5cclxuaW50ZXJmYWNlIEF1dGhTdGF0ZSB7XHJcbiAgdXNlcjogVXNlciA7XHJcbiAgdG9rZW46IHN0cmluZyB8ICcnO1xyXG59O1xyXG5cclxuY29uc3Qgc2xpY2UgPSBjcmVhdGVTbGljZSh7XHJcbiAgbmFtZTogXCJhdXRoXCIsXHJcbiAgaW5pdGlhbFN0YXRlOiB7XHJcbiAgICB0b2tlbjogZ2V0RnJvbUxvY2FsU3RvcmFnZShcInRva2VuXCIpID8gZ2V0RnJvbUxvY2FsU3RvcmFnZShcInRva2VuXCIpIDogJycsXHJcbiAgICB1c2VyOiBnZXRGcm9tTG9jYWxTdG9yYWdlKFwidXNlclwiKSA/IEpTT04ucGFyc2UoZ2V0RnJvbUxvY2FsU3RvcmFnZShcInVzZXJcIikgPz8gSlNPTi5zdHJpbmdpZnkoZGVmYXVsdFVzZXIpKSA6IGRlZmF1bHRVc2VyXHJcbiAgfSBhcyBBdXRoU3RhdGUsXHJcbiAgcmVkdWNlcnM6IHtcclxuICAgIHNldENyZWRlbnRpYWxzOiAoc3RhdGUsIGFjdGlvbjogUGF5bG9hZEFjdGlvbjxBdXRoU3RhdGU+KSA9PiB7XHJcbiAgICAgIHN0YXRlLnRva2VuID0gYWN0aW9uLnBheWxvYWQudG9rZW47XHJcbiAgICAgIHN0YXRlLnVzZXIgPSBhY3Rpb24ucGF5bG9hZC51c2VyO1xyXG4gICAgfSxcclxuICAgIGxvZ091dDogKHN0YXRlLCBhY3Rpb24pID0+IHtcclxuICAgICAgc3RhdGUudG9rZW4gPSAnJztcclxuICAgICAgc3RhdGUudXNlciA9IGRlZmF1bHRVc2VyO1xyXG4gICAgfVxyXG4gIH0sXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNvbnN0IHsgc2V0Q3JlZGVudGlhbHMsIGxvZ091dCB9ID0gc2xpY2UuYWN0aW9ucztcclxuZXhwb3J0IGRlZmF1bHQgc2xpY2UucmVkdWNlcjtcclxuZXhwb3J0IGNvbnN0IHNlbGVjdEN1cnJlbnRVc2VyOiBhbnkgPSAoc3RhdGU6IFJvb3RTdGF0ZSkgPT4gc3RhdGUuYXV0aC51c2VyO1xyXG5leHBvcnQgY29uc3Qgc2VsZWN0Q3VycmVudFRva2VuOiBhbnkgPSAoc3RhdGU6IFJvb3RTdGF0ZSkgPT4geyByZXR1cm4gc3RhdGUuYXV0aC50b2tlbiB9O1xyXG4iXSwibmFtZXMiOlsiY3JlYXRlU2xpY2UiLCJnZXRGcm9tTG9jYWxTdG9yYWdlIiwiZGVmYXVsdFVzZXIiLCJmaXJzdG5hbWUiLCJpZCIsImVtYWlsIiwidmVyaWZpZWQiLCJzbGljZSIsIm5hbWUiLCJpbml0aWFsU3RhdGUiLCJ0b2tlbiIsInVzZXIiLCJKU09OIiwicGFyc2UiLCJzdHJpbmdpZnkiLCJyZWR1Y2VycyIsInNldENyZWRlbnRpYWxzIiwic3RhdGUiLCJhY3Rpb24iLCJwYXlsb2FkIiwibG9nT3V0IiwiYWN0aW9ucyIsInJlZHVjZXIiLCJzZWxlY3RDdXJyZW50VXNlciIsImF1dGgiLCJzZWxlY3RDdXJyZW50VG9rZW4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/lib/slice/authslice.ts\n");

/***/ }),

/***/ "./src/lib/store.ts":
/*!**************************!*\
  !*** ./src/lib/store.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"makeStore\": () => (/* binding */ makeStore),\n/* harmony export */   \"wrapper\": () => (/* binding */ wrapper)\n/* harmony export */ });\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ \"@reduxjs/toolkit\");\n/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-redux-wrapper */ \"next-redux-wrapper\");\n/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./api */ \"./src/lib/api.ts\");\n/* harmony import */ var _slice_authslice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./slice/authslice */ \"./src/lib/slice/authslice.ts\");\n\n\n\n\nconst makeStore = ()=>{\n    return (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({\n        reducer: {\n            auth: _slice_authslice__WEBPACK_IMPORTED_MODULE_3__[\"default\"],\n            [_api__WEBPACK_IMPORTED_MODULE_2__.sungloApi.reducerPath]: _api__WEBPACK_IMPORTED_MODULE_2__.sungloApi.reducer\n        },\n        middleware: (gDM)=>gDM().concat(_api__WEBPACK_IMPORTED_MODULE_2__.sungloApi.middleware)\n    });\n};\nconst wrapper = (0,next_redux_wrapper__WEBPACK_IMPORTED_MODULE_1__.createWrapper)(makeStore, {\n    debug: true\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvbGliL3N0b3JlLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQWtEO0FBQ0M7QUFDakI7QUFDUTtBQUVuQyxNQUFNSSxZQUFZLElBQVc7SUFDbEMsT0FBT0osZ0VBQWNBLENBQUM7UUFDcEJLLFNBQVM7WUFDUEMsTUFBTUgsd0RBQVNBO1lBQ2YsQ0FBQ0QsdURBQXFCLENBQUMsRUFBRUEsbURBQWlCO1FBQzVDO1FBQ0FNLFlBQVksQ0FBQ0MsTUFBUUEsTUFBTUMsTUFBTSxDQUFDUixzREFBb0I7SUFDeEQ7QUFDRixFQUFFO0FBTUssTUFBTVMsVUFBVVYsaUVBQWFBLENBQVdHLFdBQVc7SUFBRVEsT0FBTyxJQUFJO0FBQUMsR0FBRyIsInNvdXJjZXMiOlsid2VicGFjazovL3Bob25lLXN3YXBwZXItYXBwLy4vc3JjL2xpYi9zdG9yZS50cz9hZDMzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNvbmZpZ3VyZVN0b3JlIH0gZnJvbSAnQHJlZHV4anMvdG9vbGtpdCc7XHJcbmltcG9ydCB7IGNyZWF0ZVdyYXBwZXIgfSBmcm9tICduZXh0LXJlZHV4LXdyYXBwZXInO1xyXG5pbXBvcnQgeyBzdW5nbG9BcGkgfSBmcm9tICcuL2FwaSc7XHJcbmltcG9ydCBhdXRoc2xpY2UgZnJvbSAnLi9zbGljZS9hdXRoc2xpY2UnO1xyXG5cclxuZXhwb3J0IGNvbnN0IG1ha2VTdG9yZSA9ICgpOiBhbnkgPT4ge1xyXG4gIHJldHVybiBjb25maWd1cmVTdG9yZSh7XHJcbiAgICByZWR1Y2VyOiB7XHJcbiAgICAgIGF1dGg6IGF1dGhzbGljZSxcclxuICAgICAgW3N1bmdsb0FwaS5yZWR1Y2VyUGF0aF06IHN1bmdsb0FwaS5yZWR1Y2VyLFxyXG4gICAgfSxcclxuICAgIG1pZGRsZXdhcmU6IChnRE0pID0+IGdETSgpLmNvbmNhdChzdW5nbG9BcGkubWlkZGxld2FyZSksXHJcbiAgfSk7XHJcbn07XHJcblxyXG5leHBvcnQgdHlwZSBBcHBTdG9yZSA9IFJldHVyblR5cGU8dHlwZW9mIG1ha2VTdG9yZT47XHJcbmV4cG9ydCB0eXBlIFJvb3RTdGF0ZSA9IFJldHVyblR5cGU8QXBwU3RvcmVbJ2dldFN0YXRlJ10+O1xyXG5leHBvcnQgdHlwZSBBcHBEaXNwYXRjaCA9IEFwcFN0b3JlWydkaXNwYXRjaCddO1xyXG5cclxuZXhwb3J0IGNvbnN0IHdyYXBwZXIgPSBjcmVhdGVXcmFwcGVyPEFwcFN0b3JlPihtYWtlU3RvcmUsIHsgZGVidWc6IHRydWUgfSk7XHJcbiJdLCJuYW1lcyI6WyJjb25maWd1cmVTdG9yZSIsImNyZWF0ZVdyYXBwZXIiLCJzdW5nbG9BcGkiLCJhdXRoc2xpY2UiLCJtYWtlU3RvcmUiLCJyZWR1Y2VyIiwiYXV0aCIsInJlZHVjZXJQYXRoIiwibWlkZGxld2FyZSIsImdETSIsImNvbmNhdCIsIndyYXBwZXIiLCJkZWJ1ZyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/lib/store.ts\n");

/***/ }),

/***/ "./src/pages/_app.tsx":
/*!****************************!*\
  !*** ./src/pages/_app.tsx ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _lib_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/lib/store */ \"./src/lib/store.ts\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/styles/globals.css */ \"./src/styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction MyApp({ Component , pageProps  }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n        ...pageProps\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Golden Mac-Eteli\\\\Documents\\\\Work\\\\Devcanoe\\\\Projects\\\\Clients\\\\Doadesign\\\\phone-swapper-app\\\\src\\\\pages\\\\_app.tsx\",\n        lineNumber: 6,\n        columnNumber: 10\n    }, this);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_lib_store__WEBPACK_IMPORTED_MODULE_1__.wrapper.withRedux(MyApp));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2FwcC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFzQztBQUNUO0FBRzdCLFNBQVNDLE1BQU0sRUFBRUMsVUFBUyxFQUFFQyxVQUFTLEVBQVksRUFBRTtJQUNqRCxxQkFBTyw4REFBQ0Q7UUFBVyxHQUFHQyxTQUFTOzs7Ozs7QUFDakM7QUFFQSxpRUFBZUgseURBQWlCLENBQUNDLE1BQU1BLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9waG9uZS1zd2FwcGVyLWFwcC8uL3NyYy9wYWdlcy9fYXBwLnRzeD9mOWQ2Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHdyYXBwZXIgfSBmcm9tICdAL2xpYi9zdG9yZSc7XG5pbXBvcnQgJ0Avc3R5bGVzL2dsb2JhbHMuY3NzJ1xuaW1wb3J0IHR5cGUgeyBBcHBQcm9wcyB9IGZyb20gJ25leHQvYXBwJ1xuXG5mdW5jdGlvbiBNeUFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH06IEFwcFByb3BzKSB7XG4gIHJldHVybiA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG59XG5cbmV4cG9ydCBkZWZhdWx0IHdyYXBwZXIud2l0aFJlZHV4KE15QXBwKTtcbiJdLCJuYW1lcyI6WyJ3cmFwcGVyIiwiTXlBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJ3aXRoUmVkdXgiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/_app.tsx\n");

/***/ }),

/***/ "./src/utils/localstorage.ts":
/*!***********************************!*\
  !*** ./src/utils/localstorage.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"getFromLocalStorage\": () => (/* binding */ getFromLocalStorage)\n/* harmony export */ });\nconst getFromLocalStorage = (key)=>{\n    if (!key || \"undefined\" === \"undefined\") {\n        return \"\";\n    }\n    return localStorage.getItem(key);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvdXRpbHMvbG9jYWxzdG9yYWdlLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7QUFBTyxNQUFNQSxzQkFBc0IsQ0FBQ0MsTUFBZ0I7SUFDaEQsSUFBSSxDQUFDQSxPQUFPLGdCQUFrQixhQUFhO1FBQ3ZDLE9BQU87SUFDWCxDQUFDO0lBQ0QsT0FBT0MsYUFBYUMsT0FBTyxDQUFDRjtBQUM5QixFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vcGhvbmUtc3dhcHBlci1hcHAvLi9zcmMvdXRpbHMvbG9jYWxzdG9yYWdlLnRzP2EyY2UiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IGdldEZyb21Mb2NhbFN0b3JhZ2UgPSAoa2V5OiBzdHJpbmcpID0+IHtcclxuICAgIGlmICgha2V5IHx8IHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgcmV0dXJuIFwiXCJcclxuICAgIH1cclxuICAgIHJldHVybiBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShrZXkpXHJcbiAgfSJdLCJuYW1lcyI6WyJnZXRGcm9tTG9jYWxTdG9yYWdlIiwia2V5IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/utils/localstorage.ts\n");

/***/ }),

/***/ "./src/styles/globals.css":
/*!********************************!*\
  !*** ./src/styles/globals.css ***!
  \********************************/
/***/ (() => {



/***/ }),

/***/ "@reduxjs/toolkit":
/*!***********************************!*\
  !*** external "@reduxjs/toolkit" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ "@reduxjs/toolkit/query/react":
/*!***********************************************!*\
  !*** external "@reduxjs/toolkit/query/react" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit/query/react");

/***/ }),

/***/ "next-redux-wrapper":
/*!*************************************!*\
  !*** external "next-redux-wrapper" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next-redux-wrapper");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/_app.tsx"));
module.exports = __webpack_exports__;

})();